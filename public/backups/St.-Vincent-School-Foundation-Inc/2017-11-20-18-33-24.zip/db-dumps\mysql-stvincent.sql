
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `combinations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `combinations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `combination` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `interpretation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `careers` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `career_count` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `combinations` WRITE;
/*!40000 ALTER TABLE `combinations` DISABLE KEYS */;
INSERT INTO `combinations` VALUES (1,'ESTJ','Realist who are quick to make practical decisions.','Insurance sales agent,Pharmacist,Lawyer,Project Manager,Judge',5,'2017-11-09 13:28:09','2017-11-09 13:28:13'),(2,'ISTJ','Hard workers who value their responsibilities and commitments.','Auditor,Accountant,Chief financial officer,Web development engineer,Government employee',5,'2017-11-04 14:50:13','2017-11-04 14:50:15'),(3,'ESTP','Pragmatists who love excitement excel in a crisis.','Detective,Banker,Investor,Entertainment agent,Sports coach',5,'2017-11-04 14:50:13','2017-11-04 14:50:15'),(4,'ISTP','Straightforward and honest people who prefer action to conversation.','Civil engineer,Economist,Pilot,Data communications analyst,Emergency room physician',5,'2017-11-04 14:50:13','2017-11-04 14:50:15'),(5,'ESFJ','Gregarious traditionalists motivated to help others.','Sales representative,Nurse/Healthcare worker,Social worker,PR account executive,Loan officer',5,'2017-11-04 14:50:13','2017-11-04 14:50:15'),(6,'ISFJ','Modest and determined workers who enjoy helping others.','Dentist,Elementary school teacher,Librarian,Franchise owner,Customer service representative',5,'2017-11-04 14:50:13','2017-11-04 14:50:15'),(7,'ESFP','Lively and playful people who value common sense.','Child welfare counselor,Primary care physician,Actor,Interior designer,Environmental scientist',5,'2017-11-04 14:50:13','2017-11-04 14:50:15'),(8,'ISFP','Warm and sensitive types who like to help people in tangible ways.','Fashion designer,Physical therapist,Massage therapist,Landscape architect,Storekeeper',5,'2017-11-04 14:50:13','2017-11-04 14:50:15'),(9,'ENTJ','Natural leaders who are logical, analytical, and good strategic planners.','Executive,Lawyer,Market research analyst,Management/Business consultant,Judge',5,'2017-11-04 14:50:13','2017-11-04 14:50:15'),(10,'INTJ','Creative perfectionists who prefer to do things their own way.','Investment banker,Personal financial adviser,Software developer,Economist,Executive',5,'2017-11-04 14:50:13','2017-11-04 14:50:15'),(11,'ENTP','Enterprising creative people who enjoy new challenges.','Entrepreneur,Real estate developer,Advertising creative director,Marketing director,Politician/Political consultant',5,'2017-11-04 14:50:13','2017-11-04 14:50:15'),(12,'INTP','Independent and creative problem-solvers.','Computer programmer/Software designer,Financial analyst,Architect,College professor,Economist',5,'2017-11-04 14:50:13','2017-11-04 14:50:15'),(13,'ENFJ','People-lovers who are energetic, articulate, and diplomatic.','Advertising Executive,Public relations specialist,Corporate coach/Trainer,Sales Manager,Employment specialist/HR professional',5,'2017-11-04 14:50:13','2017-11-09 08:13:06'),(14,'INFJ','Thoughtful, creative people driven by firm principles and personal integrity.','Therapist/Mental health counselor,Social worker,HR diversity manager,Organizational devlopment consultant,Customer relations manager',5,'2017-11-04 14:50:13','2017-11-04 14:50:15'),(15,'ENFP','Curious and confident creative types who see possibilities everywhere.','Journalist,Advertising creative director,Consultant,Restaurateur,Event planner',5,'2017-11-04 14:50:13','2017-11-04 14:50:15'),(16,'INFP','Sensitive idealists motivated by their deeper personal values.','Graphic designer,Physchologist/Therapist,Writer/Editor,Physical Therapist,HR development trainer',5,'2017-11-04 14:50:13','2017-11-04 14:50:15');
/*!40000 ALTER TABLE `combinations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `exam_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_limits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lrn` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exam_count` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `exam_limits` WRITE;
/*!40000 ALTER TABLE `exam_limits` DISABLE KEYS */;
INSERT INTO `exam_limits` VALUES (1,'234234234234',0,'2017-11-18 20:43:46','2017-11-18 20:43:46'),(2,'231231231231',0,'2017-11-20 05:26:15','2017-11-20 05:26:15');
/*!40000 ALTER TABLE `exam_limits` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (17,'2014_10_12_100000_create_password_resets_table',1),(18,'2017_11_04_081319_create_roles_table',1),(20,'2017_11_04_154541_create_questions_table',3),(21,'2017_11_04_172252_create_question2s_table',4),(27,'2017_11_04_202730_create_results_table',8),(29,'2017_11_04_144702_create_combinations_table',9),(32,'2014_10_12_000000_create_users_table',11),(36,'2017_11_15_011948_create_remarks_table',13),(37,'2017_11_05_164509_create_students_table',14),(38,'2017_11_05_081223_create_exam_limits_table',15);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `letter_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statement` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statement_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_no` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (1,'E,I','Highly energized by being with other people,Are energized by being alone','Energy',1,'2017-11-04 11:00:35','2017-11-14 05:49:13'),(2,'E,I','Center of attention,Do not want to be the center of attention','Energy',2,'2017-11-04 11:14:59','2017-11-04 11:14:59'),(3,'S,N','Prefers concrete,Imaginative','Information',3,'2017-11-04 11:43:34','2017-11-04 11:43:34'),(4,'S,N','Use new ideas if they have practical applications,Use new ideas and concepts for own self','Information',4,'2017-11-04 11:45:38','2017-11-04 11:45:38'),(5,'T,F','Step back,Step forward','Decision Making',5,'2017-11-04 11:46:15','2017-11-04 11:46:15'),(6,'T,F','Value logic,Value empathy','Decision Making',6,'2017-11-04 11:46:41','2017-11-04 11:46:41'),(7,'J,P','Organized,Disorganized','Learning Style',7,'2017-11-04 11:46:58','2017-11-04 11:46:58'),(8,'J,P','Planned,Flexible','Learning Style',8,'2017-11-04 11:47:43','2017-11-04 11:47:43'),(9,'E,I','Act first, then think,Think before you act','Energy',9,'2017-11-04 12:16:20','2017-11-04 12:16:20'),(10,'E,I','Think out loud,Think things through silently','Energy',10,'2017-11-04 12:16:37','2017-11-04 12:16:37'),(11,'E,I','Are easier to read and know personally,Are more private in personal information','Energy',11,'2017-11-04 12:16:48','2017-11-04 12:16:48'),(12,'E,I','Talkative,Listener','Energy',12,'2017-11-04 12:16:59','2017-11-04 12:16:59'),(13,'E,I','Enthusiastic,Keep enthusiasm to self','Energy',13,'2017-11-04 12:17:14','2017-11-04 12:17:14'),(14,'E,I','Respond Quickly,Take time to think before responding','Energy',14,'2017-11-04 12:17:25','2017-11-04 12:17:25'),(15,'E,I','Fast pace,Slow pace','Energy',15,'2017-11-04 12:17:42','2017-11-04 12:17:42');
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `remarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `remarks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lrn` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `remarks` WRITE;
/*!40000 ALTER TABLE `remarks` DISABLE KEYS */;
/*!40000 ALTER TABLE `remarks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `results` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lrn` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `e_percentage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `i_percentage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `s_percentage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `n_percentage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `t_percentage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f_percentage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_percentage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `j_percentage` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `interpretation` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `results` WRITE;
/*!40000 ALTER TABLE `results` DISABLE KEYS */;
INSERT INTO `results` VALUES (1,'2015100073','22.22%','77.78%','50%','50%','0%','100%','100%','0%','Sensitive idealists motivated by their deeper personal values.','2017-11-15 10:14:37','2017-11-15 10:14:37'),(2,'2015100073','22.22%','77.78%','50%','50%','0%','100%','100%','0%','Sensitive idealists motivated by their deeper personal values.','2017-11-15 10:16:33','2017-11-15 10:16:33');
/*!40000 ALTER TABLE `results` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'administrator','2017-11-04 12:39:37','2017-11-04 12:39:40'),(2,'superadmin','2017-11-14 14:25:12','2017-11-14 14:25:15');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lrn` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthday` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `place_of_birth` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `home_address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grade` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name_father` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middle_name_father` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name_father` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthday_father` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation_father` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_address_father` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number_father` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name_mother` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middle_name_mother` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name_mother` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthday_mother` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation_mother` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_address_mother` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number_mother` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name_guardian` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middle_name_guardian` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name_guardian` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthday_guardian` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation_guardian` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_address_guardian` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number_guardian` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name_sibling` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middle_name_sibling` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name_sibling` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age_sibling` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_attended_kindergarten` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_completed_kindergarten` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_standing_kindergarten` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_attended_grade1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_completed_grade1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_standing_grade1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_attended_grade2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_completed_grade2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_standing_grade2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_attended_grade3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_completed_grade3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_standing_grade3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_attended_grade4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_completed_grade4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_standing_grade4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_attended_grade5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_completed_grade5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_standing_grade5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_attended_grade6` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_completed_grade6` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_standing_grade6` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_attended_grade7` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_completed_grade7` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_standing_grade7` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_attended_grade8` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_completed_grade8` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_standing_grade8` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_attended_grade9` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_completed_grade9` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_standing_grade9` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_attended_grade10` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_completed_grade10` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_standing_grade10` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_attended_grade11` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_completed_grade11` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_standing_grade11` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_attended_grade12` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_completed_grade12` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_standing_grade12` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `students_lrn_unique` (`lrn`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'2015100073','Roxel Roll','Macabudbud','Mendoza',NULL,'11/18/2017','12','Male','tarlac','San Clemente, Tarlac','39976072765','Graduate','Roxel Roll Mendoza',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-11-18 07:09:12','2017-11-18 20:57:10'),(11,'234234234234','Roxel Roll','Macabudbud','Mendoza',NULL,'11/20/2017','12','Male','tarlac','San Clemente, Tarlac','39976072765','Grade 12','Roxel Roll Mendoza',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-11-18 20:43:46','2017-11-18 20:56:31'),(12,'231231231231','dasda','dasdads','adasdasd',NULL,'11/20/2017','20','Male','tarlac','San Clemente, Tarlac','39976072765','Grade 10','Roxel Roll Mendoza',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-11-20 05:26:15','2017-11-20 05:26:15');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lrn` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_role_id_index` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'',2,'superadmin','$2y$10$gc5FwZEZm4TZ9wvzdTXJM.FKBUwVtqvarKRf873vorHejsaJZitcu','Nbg0HnThN8fnhpyGYlJQDWNVgOapyVWZ9suEVhj4ejiCWUVWXyjt82D8tjCY','2017-11-14 16:42:10','2017-11-14 16:42:13'),(2,'',1,'admin','$2y$10$gc5FwZEZm4TZ9wvzdTXJM.FKBUwVtqvarKRf873vorHejsaJZitcu','9Mgs0IQdivHStTlxfFPrqzyUvEFEvz4L6pORt7W8qFwauWPmnNnTME69BeV1','2017-11-14 16:42:30','2017-11-14 16:42:32'),(6,'231231231231',NULL,NULL,'$2y$10$ZuXPuzy2iKpYPU9nrqPmZeic7Xj7zQ7taywVHchFKzRgw0s5H02om',NULL,'2017-11-20 05:30:06','2017-11-20 05:30:06');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

